# Caizsel — Solo, dengan caramu

Formulir preferensi trip dalam bentuk jurnal perjalanan Solo. Next.js App Router + React + TypeScript + Tailwind CSS, GSAP/SplitText/ScrambleText + `@gsap/react`, lucide-react, dan Canvas 2D. Tidak ada backend, akun, database, analytics, atau API berbayar.

## Jalankan

Node.js 22+.

```bash
npm ci
npm run dev
```

Buka `http://localhost:3000`. `npm run dev -- --port 4000` juga didukung.

```bash
npm test
npm run typecheck
npm run build
```

Build menjalankan **`next build`**, dengan **`output: "export"`**. Seluruh hasil siap hosting ada di **`out/`**. Jangan memakai `next start` untuk hasil export. Folder itu dapat disajikan oleh server statis apa pun. Script dev hanya memakai server statis untuk lingkungan preview yang memberikan argumen `--strictPort`; jalankan build dahulu pada mode tersebut.

## Struktur & edit

```text
src/
  app/
    layout.tsx          Metadata, inisialisasi tema sebelum paint
    page.tsx            Halaman App Router
    globals.css         Token warna light/dark, layout, tipografi
  config.ts             Guide dan dua tautan WhatsApp
  lib/
    data.ts             Urutan soal, jenis, harga, kategori, chip, teks helper
    form.ts             Schema state, validasi, reset, restore, ringkasan & WA
    tokens.ts           Semua durasi/easing/stagger dan parameter gerak
  components/
    TravelJournal.tsx   Alur client, penyimpanan, transisi, form & boarding pass
    Controls.tsx        Tombol, kartu, indikator dan jalur rute SVG
    Ambient.tsx         Canvas dan parallax yang dibersihkan saat unmount
public/
  fonts/                Montserrat 600/700, Jakarta 400/500/600, lisensi OFL
  solo-pendopo.webp      Foto lokal teroptimasi, kredit di UI dan CREDITS.md
scripts/dev.mjs         Launcher dev / preview hasil export
tests/form.test.ts      Uji logika, dependensi, pemulihan dan encoding WA
next.config.ts          Static export; tidak menggunakan endpoint dinamis
```

Ubah `src/config.ts` untuk `guideName`, `waNumber` (angka internasional tanpa `+`) dan `waFallback`. Semua soal, opsi dan harga ada di `src/lib/data.ts`. Teks identitas asli disimpan; hanya sapaan yang memakai Title Case. Jangan mengubah urutan soal bila tidak dibutuhkan. Bila schema penyimpanan berubah, naikkan `version` dan kunci sesi di `form.ts` atau tambahkan migrasi eksplisit.

## Deploy utama: Cloudflare Pages gratis

1. Push kode ke repository GitHub/GitLab milikmu.
2. Cloudflare Dashboard → Workers & Pages → Create application → Pages → import repository.
3. Framework preset: **Next.js (Static HTML Export)**. Build: **`npm run build`** (menjalankan `next build`). Build output: **`out`**. Node: **22** atau versi lebih baru yang didukung host.
4. Deploy. Tidak perlu Worker, Pages Functions, secret, token WhatsApp, atau variabel environment.

Alternatif upload manual: build lokal lalu upload **isi `out/`** melalui Pages Direct Upload. Hosting gratis tetap mengikuti batas/ketentuan Cloudflare yang berlaku. Tidak ada rewrite SPA atau middleware yang diperlukan karena aplikasi hanya memiliki satu route `/`.

Panduan resmi: https://developers.cloudflare.com/pages/framework-guides/nextjs/deploy-a-static-nextjs-site/

## Netlify & Vercel

- **Netlify:** build `npm run build`, publish directory `out`; gunakan deployment **static** tanpa Next server adapter. Bisa juga deploy manual isi `out/`. Tinjau ketentuan paket akun dan batas penggunaan yang berlaku. Pada pengecekan **28 Oktober 2026**, dokumentasi Free berbasis kredit mencantumkan 300 kredit/bulan dengan hard limit; akun lama dapat memakai paket legacy. Jangan menganggap bandwidth/deploy tak terbatas. Lihat https://www.netlify.com/pricing/ dan https://docs.netlify.com/manage/accounts-and-billing/billing/billing-for-credit-based-plans/credit-based-pricing-plans/ .
- **Vercel:** tetap kompatibel sebagai static export, build `npm run build`, output `out`. Untuk penggunaan komersial tour guide, gunakan paket yang sesuai, seperti **Pro**. **Hobby hanya untuk penggunaan personal nonkomersial**; jumlah client tidak mengubah aturan ini. Lihat https://vercel.com/docs/limits/fair-use-guidelines dan https://vercel.com/docs/plans/hobby .

## Perilaku penting

- Identitas adalah isian lokal, bukan akun/autentikasi terverifikasi. Guard hanya berjalan di client **setelah** session dipulihkan.
- `sessionStorage` dengan kunci `caizsel.trip.v1` menyimpan nama/email, jawaban, kedua draft metode preferensi, chip/kategori, catatan, langkah, mode edit dan intro sesi. Refresh tab memulihkan langkah aktif; penutupan tab atau perangkat lain tidak dijanjikan memulihkan data. Kegagalan storage ditangani; form tetap bekerja di memori dengan pemberitahuan.
- Hanya tema yang ditulis ke `localStorage` (`caizsel.theme`). Default mengikuti sistem, termasuk perubahan sistem sampai pilihan eksplisit dibuat. Script kecil di `<head>` mencegah flash tema. Font Google disajikan lokal, sehingga runtime tidak perlu menghubungi Google Fonts.
- Preloader melacak lima file font yang digunakan serta satu foto lokal. Persentase = aset yang sudah settled / total; aset yang gagal memakai fallback dan tidak memblokir akses. Tidak ada timer progress atau penundaan minimum. Jika intro sudah dilalui atau reduced motion aktif, intro dilewati.
- Jenis penginapan berubah/dibatalkan → rentang 1A dan **seluruh** draft 2A direset. Catatan opsional dipertahankan, karena terpisah dari jawaban wajib. Basis konsumsi berubah/dibatalkan → rentang 1B direset.
- Dalam edit, **Kembali** menuju ringkasan dengan perubahan saat ini (draft selalu autosave). **Simpan perubahan** hanya aktif bila slide valid. Dampak reset pada item lain ditandai; Share tetap nonaktif sampai seluruh jawaban valid.
- Kartu kategori tanpa chip tidak menghasilkan jawaban. Pembatalan kategori menghapus chip kategori itu. Metode yang tidak aktif menyimpan draft, tetapi tidak masuk ringkasan/WA. “Tidak ada” hanya berasal dari ketikan client.
- Waktu “Diisi” dibuat saat mencapai ringkasan valid, berdasarkan jam/zona waktu perangkat. Jawaban/catatan yang berubah membatalkannya sampai ringkasan valid ditampilkan lagi. Tidak ada perhitungan total biaya.
- Share menggunakan **anchor native** `target="_blank" rel="noopener noreferrer"`. Tidak ada proses async, clipboard, animasi, atau timer sebelum pembukaan `wa.me`. Pesan **belum terkirim** sampai client menekan **Kirim di WhatsApp**. Status hanya “Formulir siap dikirim”. Tidak ada deteksi instalasi WhatsApp, nomor valid/tidak, teks terbawa, atau penerimaan guide.
- Salin teks menampilkan sukses hanya setelah clipboard berhasil. Jika tidak tersedia/ditolak, textarea readonly berisi teks lengkap ditampilkan untuk penyalinan manual. Chat alternatif selalu tersedia, tanpa pembukaan otomatis.
- Share tidak menghapus draft. Mulai ulang membersihkan sesi form dan kembali ke Kenalan; preferensi tema dipertahankan.
- Enter menggunakan perilaku native form/kontrol. Textarea tetap mendukung baris baru; tombol panah tidak diambil alih. Tombol single memakai `aria-pressed` agar dapat dibatalkan; kategori/chip tetap multi. Saat transisi, lock navigasi dan `inert` mencegah timeline bertumpuk. Hanya langkah aktif terpasang. Fokus pindah ke judul sesudah transisi.
- Reduced motion menonaktifkan scramble, reveal panjang, partikel, parallax, magnetic, dan circular reveal. Canvas berhenti ketika tab tersembunyi, menggunakan DPR dibatasi 1.5 dan 10/19 partikel. Semua listener, SplitText, timeline dan loop dibersihkan.

## Pemeriksaan

Lihat `QA.md` untuk hasil pemeriksaan produksi, logika dan browser, serta batas pengujian. Jalankan ulang `npm test` dan `npm run build` setelah mengubah data/logika. Untuk tes manual di perangkat: mulai dengan tab baru, isi seluruh alur, refresh di tengah pengisian, edit jenis penginapan dari ringkasan, lengkapi 2A lagi, Share, kembali dari WhatsApp, lalu Mulai ulang. Coba tema light/dark, zoom teks, keyboard dan pengaturan Reduce Motion perangkat.

## Asumsi implementasi

1. Foto Mangkunegaran adalah konteks editorial Solo, bukan pilihan destinasi atau pertanyaan tambahan.
2. Tanggal/jam mengikuti perangkat client; angka harga tidak diverifikasi ulang karena menggunakan data yang ditetapkan dalam brief.
3. Back pada mode edit mempertahankan perubahan sebagai draft; pengguna memperbaiki item yang ditandai melalui Ubah.
4. Tema sistem dapat berubah secara langsung, sedangkan circular reveal digunakan untuk toggle eksplisit. Tidak ada autoplay preloader pada Mulai ulang.

## Referensi gerak

Implementasi orisinal, disesuaikan ke sistem visual ini; tidak menyalin komponen pihak ketiga.

- https://reactbits.dev/animations/pixel-transition
- https://reactbits.dev/text-animations/split-text
- https://reactbits.dev/text-animations/text-scramble (rujukan efek; memakai GSAP ScrambleText)
- https://gsap.com/docs/v3/Plugins/SplitText/
- https://gsap.com/docs/v3/Plugins/ScrambleTextPlugin/
- https://gsap.com/resources/React/
- https://developer.mozilla.org/en-US/docs/Web/API/View_Transition_API
- https://uiverse.io/buttons
