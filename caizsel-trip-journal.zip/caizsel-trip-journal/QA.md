# Pemeriksaan — 28 Oktober 2026

Hasil yang dinyatakan lulus di bawah telah dijalankan. Tidak ada uji yang masih gagal pada kode final. Tes perangkat fisik dan pengiriman pesan sungguhan dipisahkan dari pemeriksaan browser.

## Otomatis

- **LULUS — 14/14** `npm test`, menggunakan Node test runner + tsx. Mencakup nama Unicode/spasi/hubung/apostrof dan batas dua huruf; email opsional; seluruh batas jam sapaan dan Title Case; validasi keenam soal; pembatalan pilihan; rentang data; reset jenis/basis; kategori kosong; penghapusan chip saat kategori dibatalkan; jawaban ketik kosong/spasi/250/251 karakter; isolasi draft metode; ringkasan/WhatsApp termasuk Rasa, label kelompok 2C, `&`, `+`, newline dan encoding; item terdampak edit; restore/guard/sanitasi; state kosong Mulai ulang.
- **LULUS** TypeScript strict dan **`next build`**. Route `/` dan `/_not-found` statis; hasil di `out/`. Tidak ada endpoint form/server dinamis.
- **LULUS — 26 pasangan warna** dari token light/dark untuk ink, muted, selected, gold-text, tombol normal/nonaktif, error, success dan focus. Rasio teks terendah yang diperiksa **4,91:1**. Light gold-text/background **6,13:1**, dark **11,23:1**. Ini pengukuran pasangan token, bukan sertifikasi audit aksesibilitas penuh.

## Browser pada hasil export produksi

| Skenario | Hasil |
| --- | --- |
| Nama `Élodie O’Neill`, email invalid lalu kosong | Lulus; tombol mengikuti validitas, error inline muncul, email kosong diterima |
| Enter pada identitas valid | Lulus; masuk Home melalui mosaic; nama sapaan Title Case |
| Sapaan perangkat | Lulus; perangkat browser menunjukkan evening; batas semua jam diuji unit |
| Lanjut awal kosong, pilih, klik lagi untuk batal | Lulus; nonaktif → aktif → nonaktif |
| Refresh di tengah 1B | Lulus; langkah, basis dan jawaban sebelumnya dipulihkan |
| Mengganti basis konsumsi | Lulus; rentang 1B kosong, harus memilih lagi |
| Jawaban ketik berisi spasi | Lulus; tidak valid |
| Berpindah metode tanpa mengirim draft nonaktif | Lulus; draft tersimpan; validasi mengikuti metode aktif |
| Space pada kontrol opsi | Lulus; memilih dengan keyboard |
| Enter di textarea jawaban | Lulus; menambah newline tanpa pindah slide |
| Kategori konsumsi tanpa chip | Lulus; belum mengaktifkan Lanjut |
| Multi kategori, batalkan Alergi sementara Rasa aktif | Lulus; chip Alergi terhapus, Rasa dipertahankan |
| Ringkasan seluruh jawaban & catatan | Lulus; Rasa dan label Aktivitas/Spot & foto muncul tepat |
| Ubah → ganti Hotel ke Vila → pilih rentang → Simpan perubahan | Lulus; kembali ringkasan; 2A ditandai Perlu diisi ulang; Share nonaktif |
| Kedua draft 2A direset akibat ganti jenis | Lulus; opsi dan textarea ketik 2A kosong |
| Perbaiki 2A dengan ketikan | Lulus; Simpan perubahan kembali ringkasan, Share aktif |
| Fokus sesudah transisi | Lulus; berpindah ke `step-heading` |
| Kembali dari 1A | Lulus; kembali Home dengan identitas tetap tersimpan |
| WhatsApp URL dan teks yang di-decode | Lulus; nomor, target, rel, format, aksen Unicode, `&`, `+` dan newline benar |
| Share, kembali ke tab formulir, refresh | Lulus; status Formulir siap dikirim dan instruksi Kirim di WhatsApp; draft tetap tersedia |
| Salin teks berhasil | Lulus; toast hanya tampil setelah keberhasilan clipboard |
| Clipboard ditolak | Lulus dengan fixture penolakan API; teks lengkap readonly dan instruksi salin manual tampil |
| Fallback chat | Lulus pemeriksaan href native dan petunjuk copy/paste; tidak dibuka otomatis |
| sessionStorage baca/tulis ditolak | Lulus dengan fixture penolakan API; pemberitahuan muncul dan identitas → Home tetap berjalan di memori |
| Dark/light, refresh tema | Lulus; tema berubah dan pilihan dipulihkan |
| Mulai ulang | Lulus; kembali Kenalan, identitas kosong dan ringkasan hilang; tema dark tetap dipertahankan |
| Layar 360px | Lulus pemeriksaan DOM pada iframe 360px (area konten 345px setelah scrollbar desktop); body scrollWidth = clientWidth; tombol Kembali/Lanjut tinggi 52px |
| Reduced motion | Lulus simulasi `matchMedia` pada fixture: intro/reveal dilewati, heading stabil, form tetap dapat dioperasikan. Pengaturan native OS belum diuji |

Fixture terisolasi memakai salinan export, state contoh, dan mock browser API; tidak termasuk kode atau hasil deploy final. Screenshot iframe tidak berhasil ditangkap oleh browser pengujian; pengukuran layout 360px di atas memakai DOM. Screenshot tampilan desktop berhasil diperiksa.

## Koreksi dari pengujian

Judul pernah menampilkan teks langkah sebelumnya akibat cleanup ScrambleText pada node React yang digunakan ulang. Panel sekarang diberi key per langkah. SplitText juga direvert setelah reveal selesai agar wrapper/label lama tidak menetap saat data berubah. Build produksi diulang dan koreksi diverifikasi di browser.

## Belum diuji secara langsung

- Safari/iOS/Android fisik, keyboard virtual, safe-area perangkat nyata, zoom teks sistem dan pembaca layar VoiceOver/TalkBack.
- Pergantian Reduce Motion dari pengaturan OS asli, fallback browser tanpa View Transitions, serta pengukuran FPS/baterai/GPU perangkat lemah. Implementasi dan cleanup ditinjau dari kode.
- Menekan **Kirim** di WhatsApp atau penerimaan pesan oleh guide. Aplikasi memang tidak dapat mendeteksi penerimaan. Pemeriksaan berhenti pada pembukaan tautan dan status kesiapan, menggunakan data contoh.
- Deployment pada akun Cloudflare Pages, Netlify atau Vercel milik pengguna. Paket ini menyertakan export statis dan panduan deploy; tidak mengklaim akun hosting pengguna telah dikonfigurasi.

## Asumsi

Catatan opsional dipertahankan saat jenis/basis diubah; jawaban wajib/draft dependennya yang direset. Kembali dalam edit menyimpan perubahan sebagai draft dan membuka ringkasan. Tanggal/jam mengikuti perangkat client. Foto hanya konteks editorial Solo.
