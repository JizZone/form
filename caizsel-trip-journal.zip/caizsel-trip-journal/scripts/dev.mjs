import { spawn } from "node:child_process";
import { createServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import { resolve, extname, sep } from "node:path";
// Mendukung argumen CLI Next dan host/strictPort dari lingkungan preview.
const args=process.argv.slice(2);let host="0.0.0.0",port="3000";
for(let i=0;i<args.length;i++){
  if(args[i]==="--host"||args[i]==="--hostname")host=args[++i]||host;
  else if(args[i]==="--port"||args[i]==="-p")port=args[++i]||port;
}
if(args.includes("--strictPort")){
  // Preview memeriksa hasil static export yang sama dengan deploy, tanpa Next server.
  const base=resolve("out");
  const mime={".html":"text/html; charset=utf-8",".js":"text/javascript; charset=utf-8",".css":"text/css; charset=utf-8",".webp":"image/webp",".woff":"font/woff",".svg":"image/svg+xml",".txt":"text/plain; charset=utf-8",".json":"application/json"};
  createServer(async(req,res)=>{try{let file=resolve(base,"."+decodeURIComponent(new URL(req.url,"http://preview.local").pathname));if(file!==base&&!file.startsWith(base+sep))throw new Error("Path");if((await stat(file)).isDirectory())file=resolve(file,"index.html");const bytes=await readFile(file);res.writeHead(200,{"Content-Type":mime[extname(file)]||"application/octet-stream"});res.end(bytes);}catch{res.writeHead(404);res.end("Not found");}}).listen(Number(port),host,()=>console.log(`Static preview ready on ${port}`));
}else{
  const child=spawn(process.execPath,["node_modules/next/dist/bin/next","dev","--hostname",host,"--port",port],{stdio:"inherit",env:process.env});
  for(const signal of ["SIGINT","SIGTERM"])process.on(signal,()=>child.kill(signal));
  child.on("exit",code=>process.exit(code??0));
}
