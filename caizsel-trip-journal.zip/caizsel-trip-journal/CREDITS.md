# Aset

Foto `public/solo-pendopo.webp`: **Grand Pendopo, Mangkunegaran Palace**, **Crisco 1492 / Chris Woodrich**, 3 Desember 2013. Sumber: https://commons.wikimedia.org/wiki/File:Grand_Pendopo,_Mangkunegaran_Palace.jpg . Lisensi **CC BY-SA 3.0 Unported**: https://creativecommons.org/licenses/by-sa/3.0/ . Perubahan: diperkecil dan dikompresi ke WebP; penayangan memakai crop, sudut membulat dan overlay gelap. Versi aset foto ini tetap didistribusikan di bawah CC BY-SA 3.0. Tidak menyiratkan dukungan fotografer terhadap layanan guide.

Font **Montserrat** (weight 600/700) dan **Plus Jakarta Sans** (400/500/600) diunduh dari Google Fonts, disajikan lokal tanpa modifikasi isi font. Lisensi **SIL Open Font License 1.1**, disertakan bersama file font. Sumber font: https://fonts.google.com/specimen/Montserrat dan https://fonts.google.com/specimen/Plus+Jakarta+Sans .

Ikon: **Lucide**, ISC License, melalui paket `lucide-react`. https://lucide.dev/license .

Referensi gerak dijelaskan di README; kode implementasi dibuat untuk proyek ini.
