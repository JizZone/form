"use client";
import { useEffect, useRef, useState, type FormEvent, type MouseEvent, type CSSProperties } from "react";
import { flushSync } from "react-dom";
import gsap from "gsap";
import { useGSAP } from "@gsap/react";
import { SplitText } from "gsap/SplitText";
import { ScrambleTextPlugin } from "gsap/ScrambleTextPlugin";
import { ArrowLeft, ArrowRight, ArrowUpRight, Check, CheckCheck, Compass, Copy, ExternalLink, MapPin, Moon, RotateCcw, Send, ShieldCheck, Sun, Ticket, AlertCircle, PenLine, ListChecks } from "lucide-react";
import { config } from "@/config";
import { avoidOptions, dailyRanges, formatRange, letters, lodgingKinds, lodgingRanges, mealBases, mealRanges, preferenceGroups, preferenceHelp, questionIds, questions, sessionHelp, type Letter, type LodgingKind, type MealBasis, type QuestionId } from "@/lib/data";
import { allValid, answerText, changeLodging, changeMealBasis, formatFilledAt, greeting, initialState, isValid, restoreState, SESSION_KEY, THEME_KEY, titleCase, toggle, toggleCategory, validEmail, validIdentity, validName, whatsappText, whatsappUrl, type FormState, type Preference, type PreferenceId, type Step } from "@/lib/form";
import { T } from "@/lib/tokens";
import { Ambient, Parallax } from "./Ambient";
import { MotionButton, OptionCard, RouteProgress } from "./Controls";

gsap.registerPlugin(useGSAP,SplitText,ScrambleTextPlugin);
type Update=(change:(s:FormState)=>FormState)=>void;
type NavOptions={editing?:QuestionId|null;intro?:boolean;reset?:boolean};

export default function TravelJournal(){
  const [form,setForm]=useState<FormState>(initialState);
  const [ready,setReady]=useState(false),[loading,setLoading]=useState(true),[progress,setProgress]=useState(0);
  const [reduced,setReduced]=useState(true),[theme,setTheme]=useState<"light"|"dark">("light");
  const [busy,setBusy]=useState(false),[notice,setNotice]=useState(""),[toast,setToast]=useState("");
  const [storageWarning,setStorageWarning]=useState(""),[manualCopy,setManualCopy]=useState(false);
  const [now,setNow]=useState<Date|null>(null);
  const [touched,setTouched]=useState({name:false,email:false});
  const root=useRef<HTMLDivElement>(null),panel=useRef<HTMLElement>(null),pixels=useRef<HTMLDivElement>(null),curtain=useRef<HTMLDivElement>(null);
  const navLock=useRef(false),introInFlight=useRef(false),timeline=useRef<gsap.core.Timeline|null>(null),direction=useRef(1),explicitTheme=useRef(false),themeLock=useRef(false);
  const writeFailed=useRef(false),latest=useRef(form);latest.current=form;

  useEffect(()=>{
    let active=true;
    const motion=matchMedia("(prefers-reduced-motion: reduce)");setReduced(motion.matches);
    const onMotion=()=>setReduced(motion.matches);motion.addEventListener("change",onMotion);
    let restored=initialState();
    try{const raw=sessionStorage.getItem(SESSION_KEY);if(raw)restored=restoreState(raw);}catch{setStorageWarning("Isian sebelumnya tidak dapat dipulihkan. Kamu tetap bisa mengisi formulir di tab ini.");}
    try{const t=localStorage.getItem(THEME_KEY);explicitTheme.current=t==="light"||t==="dark";}catch{}
    setTheme(document.documentElement.dataset.theme==="dark"?"dark":"light");
    const scheme=matchMedia("(prefers-color-scheme: dark)");
    const onScheme=()=>{if(!explicitTheme.current){document.documentElement.dataset.theme=scheme.matches?"dark":"light";setTheme(scheme.matches?"dark":"light");}};scheme.addEventListener("change",onScheme);
    setNow(new Date());
    if(restored.introSeen||motion.matches){restored.introSeen=true;setLoading(false);setProgress(100);}
    setForm(restored);setReady(true);
    if(!restored.introSeen&&!motion.matches){
      // Progress adalah jumlah aset settled / jumlah aset yang benar-benar dimuat.
      const fonts=document.fonts?[document.fonts.load('600 16px "Montserrat"'),document.fonts.load('700 16px "Montserrat"'),document.fonts.load('400 16px "Plus Jakarta Sans"'),document.fonts.load('500 16px "Plus Jakarta Sans"'),document.fonts.load('600 16px "Plus Jakarta Sans"')]:[];
      const photo=new Promise<void>(resolve=>{const img=new Image();img.onload=()=>resolve();img.onerror=()=>resolve();img.src="/solo-pendopo.webp";if(img.complete)resolve();});
      const assets=[...fonts,photo];let settled=0;
      Promise.allSettled(assets.map(p=>Promise.resolve(p).finally(()=>{settled++;if(active)setProgress(Math.round(settled/assets.length*100));}))).then(()=>{if(active){setProgress(100);setForm(s=>({...s,introSeen:true}));setLoading(false);}});
    }
    return()=>{active=false;motion.removeEventListener("change",onMotion);scheme.removeEventListener("change",onScheme);};
  },[]);
  useEffect(()=>{
    if(!ready)return;
    try{sessionStorage.setItem(SESSION_KEY,JSON.stringify(form));}catch{if(!writeFailed.current){writeFailed.current=true;setStorageWarning("Penyimpanan tab tidak tersedia. Isian tetap bisa diisi, tetapi tidak dapat dijamin pulih setelah refresh.");}}
  },[form,ready]);
  useEffect(()=>{
    if(ready&&!validIdentity(form.identity)&&form.step!=="identity")setForm(s=>({...s,step:"identity",editing:null}));
  },[ready,form.identity,form.step]);
  useEffect(()=>{if(!toast)return;const timer=setTimeout(()=>setToast(""),T.toast*1000);return()=>clearTimeout(timer);},[toast]);
  useEffect(()=>{if(form.step==="home")setNow(new Date());},[form.step]);
  useEffect(()=>{if(ready&&!loading&&!busy)panel.current?.querySelector<HTMLElement>("[data-step-heading]")?.focus({preventScroll:true});},[ready,loading,busy,form.step]);
  useEffect(()=>()=>{timeline.current?.kill();},[]);
  useEffect(()=>{if(reduced){timeline.current?.kill();introInFlight.current=false;navLock.current=false;setBusy(false);if(pixels.current)gsap.set(pixels.current,{display:"none"});if(curtain.current)gsap.set(curtain.current,{scaleY:0});}},[reduced]);
  // Hanya langkah aktif terpasang; reveal tidak bergantung pada jawaban/ketikan.
  useGSAP(()=>{
    if(!ready||loading||!panel.current)return;
    const el=panel.current;const splits:SplitText[]=[];
    const focus=()=>{splits.splice(0).forEach(s=>s.revert());if(!introInFlight.current){navLock.current=false;setBusy(false);}};
    if(reduced){gsap.set(el,{clearProps:"opacity,transform,clipPath"});focus();return;}
    const tl=gsap.timeline({onComplete:focus});
    tl.fromTo(el,{opacity:0,y:direction.current*T.slide.offset,clipPath:direction.current>0?"inset(0% 0% 12% 0%)":"inset(12% 0% 0% 0%)"},{opacity:1,y:0,clipPath:"inset(0% 0% 0% 0%)",duration:T.slide.enter,ease:T.out});
    const greetingEl=el.querySelector<HTMLElement>("[data-greeting]");
    if(greetingEl){const split=SplitText.create(greetingEl,{type:"words,chars",aria:"auto"});splits.push(split);tl.from(split.chars,{y:T.text.offset,opacity:0,filter:`blur(${T.text.blur}px)`,duration:T.text.duration,stagger:{amount:T.text.maxStagger},ease:T.out},0);}
    el.querySelectorAll<HTMLElement>(".reveal-option").forEach(text=>{const split=SplitText.create(text,{type:"lines,words",mask:"lines",aria:"auto"});splits.push(split);tl.from(split.words,{yPercent:T.text.optionY,opacity:0,filter:`blur(${T.text.blur}px)`,duration:T.text.duration,stagger:{amount:T.text.stagger*3},ease:T.out},0);});
    const scramble=el.querySelector<HTMLElement>("[data-scramble]");if(scramble)tl.to(scramble,{duration:T.text.scramble,scrambleText:{text:scramble.textContent||"",chars:T.text.charset,revealDelay:0},ease:T.ease},0);
    const cards=el.querySelectorAll(".option-card,.stagger-in");if(cards.length)tl.from(cards,{opacity:0,y:T.slide.offset,duration:T.slide.enter,stagger:Math.min(T.slide.stagger,T.slide.maxStagger),ease:T.out},0);
    return()=>{tl.kill();splits.forEach(s=>s.revert());};
  },{scope:root,dependencies:[ready,loading,form.step,reduced],revertOnUpdate:true});
  useGSAP(()=>{
    if(!ready||loading||reduced)return;
    const stamps=[...root.current?.querySelectorAll<HTMLElement>(".travel-stamp,.hello-compass>svg")??[]].filter(el=>el.getClientRects().length>0);
    if(!stamps.length)return;
    const float=gsap.to(stamps,{y:T.ambient.floatDistance,duration:T.ambient.float,repeat:-1,yoyo:true,ease:T.ambient.floatEase});
    const visibility=()=>{if(document.hidden)float.pause();else float.resume();};visibility();document.addEventListener("visibilitychange",visibility);
    return()=>{float.kill();document.removeEventListener("visibilitychange",visibility);};
  },{scope:root,dependencies:[ready,loading,form.step,reduced],revertOnUpdate:true});

  const update:Update=change=>{setForm(s=>({...change(s),shared:false,filledAt:null}));setManualCopy(false);};
  function go(target:Step,options:NavOptions={}){
    if(navLock.current||(target===latest.current.step&&!options.reset))return;
    if(target!=="identity"&&!validIdentity(latest.current.identity))target="identity";
    navLock.current=true;setBusy(true);setNotice("");setManualCopy(false);
    direction.current=stepIndex(target)>=stepIndex(latest.current.step)?1:-1;
    const commit=()=>{
      if(options.reset){try{sessionStorage.removeItem(SESSION_KEY);}catch{};setTouched({name:false,email:false});}
      setForm(s=>{const next=options.reset?{...initialState(),introSeen:true}:{...s,step:target,editing:options.editing??null};if(target==="summary"&&allValid(next))next.filledAt=next.filledAt??new Date().toISOString();return next;});
      window.scrollTo({top:0,behavior:"instant"});
    };
    timeline.current?.kill();
    if(reduced){commit();return;}
    if(options.intro&&pixels.current){
      introInFlight.current=true;const cells=pixels.current.children;
      gsap.set(pixels.current,{display:"grid"});gsap.set(cells,{opacity:0,scale:T.intro.scale});
      timeline.current=gsap.timeline({onComplete:()=>{gsap.set(pixels.current,{display:"none"});introInFlight.current=false;navLock.current=false;setBusy(false);}})
        .to(cells,{opacity:1,scale:1,duration:T.intro.cover,stagger:{amount:T.intro.stagger*T.intro.columns*4,from:"random"},ease:T.ease})
        .call(commit)
        .to(cells,{opacity:0,scale:T.intro.scale,duration:T.intro.uncover,stagger:{amount:T.intro.stagger*T.intro.columns*4,from:"random"},ease:T.out});
    }else{
      timeline.current=gsap.timeline().to(panel.current,{opacity:0,y:-direction.current*T.slide.offset,duration:T.slide.exit,ease:T.ease},0).fromTo(curtain.current,{scaleY:0,transformOrigin:direction.current>0?"bottom":"top"},{scaleY:1,duration:T.slide.exit,ease:T.ease},0).call(commit).to(curtain.current,{scaleY:0,transformOrigin:direction.current>0?"top":"bottom",duration:T.slide.curtain,ease:T.out});
    }
  }
  function next(e:FormEvent){e.preventDefault();const current=latest.current;if(busy||!questionIds.includes(current.step as QuestionId)||!isValid(current,current.step as QuestionId))return;const i=questionIds.indexOf(current.step as QuestionId);go(current.editing?"summary":questionIds[i+1]??"summary");}
  function back(){if(form.editing){go("summary");return;}const i=questionIds.indexOf(form.step as QuestionId);go(i>0?questionIds[i-1]:"home");}
  function themeToggle(e:MouseEvent<HTMLButtonElement>){
    if(themeLock.current)return;const nextTheme=theme==="dark"?"light":"dark";
    explicitTheme.current=true;try{localStorage.setItem(THEME_KEY,nextTheme);}catch{setToast("Tema berlaku di halaman ini; preferensinya tidak dapat disimpan.");}
    const apply=()=>{document.documentElement.dataset.theme=nextTheme;flushSync(()=>setTheme(nextTheme));};
    const doc=document as Document&{startViewTransition?:(callback:()=>void)=>{ready:Promise<void>;finished:Promise<void>}};
    if(reduced){apply();return;}
    if(doc.startViewTransition){themeLock.current=true;const rect=e.currentTarget.getBoundingClientRect(),x=rect.left+rect.width/2,y=rect.top+rect.height/2,r=Math.hypot(Math.max(x,innerWidth-x),Math.max(y,innerHeight-y));
      try{const transition=doc.startViewTransition(apply);transition.ready.then(()=>{document.documentElement.animate({clipPath:[`circle(0px at ${x}px ${y}px)`,`circle(${r}px at ${x}px ${y}px)`]},{duration:T.theme.duration*1000,easing:T.theme.ease,pseudoElement:"::view-transition-new(root)"});}).catch(()=>{});transition.finished.finally(()=>{themeLock.current=false;}).catch(()=>{themeLock.current=false;});}catch{themeLock.current=false;apply();}
    }else{gsap.to(root.current,{opacity:T.theme.fadeOpacity,duration:T.theme.fade/2,onComplete:()=>{apply();gsap.to(root.current,{opacity:1,duration:T.theme.fade/2});}});}
  }
  async function copyText(){
    const text=whatsappText(latest.current);if(!text)return;
    try{if(!navigator.clipboard?.writeText)throw new Error("No clipboard");await navigator.clipboard.writeText(text);setToast("Teks formulir berhasil disalin.");setManualCopy(false);}catch{setManualCopy(true);setToast("Salin otomatis tidak tersedia. Pilih dan salin teks di bawah secara manual.");}
  }
  const {contextSafe}=useGSAP({scope:root});
  const clickMotion=contextSafe((e:MouseEvent<HTMLDivElement>)=>{
    const button=(e.target as HTMLElement).closest<HTMLElement>("[data-motion]");if(!button||button.hasAttribute("disabled")||button.getAttribute("aria-disabled")==="true"||reduced)return;
    try{navigator.vibrate?.(T.click.haptic);}catch{}
    const r=button.getBoundingClientRect(),ripple=document.createElement("span");ripple.className="click-ripple";ripple.setAttribute("aria-hidden","true");const size=Math.max(r.width,r.height)*T.click.rippleDiameter;ripple.style.cssText=`width:${size}px;height:${size}px;left:${(e.clientX||r.left+r.width/2)-r.left-size/2}px;top:${(e.clientY||r.top+r.height/2)-r.top-size/2}px;`;button.appendChild(ripple);
    gsap.fromTo(ripple,{scale:0,opacity:T.click.rippleAlpha},{scale:1,opacity:0,duration:T.click.ripple,ease:T.out,onComplete:()=>ripple.remove()});gsap.fromTo(button,{scale:T.click.scale},{scale:1,duration:T.click.duration,ease:T.spring,overwrite:"auto"});
  });
  const index=questionIds.indexOf(form.step as QuestionId),isQuestion=index>=0;
  const canShare=allValid(form)&&!!form.filledAt;
  const dateStamp=now?new Intl.DateTimeFormat("id-ID",{day:"2-digit",month:"short",year:"numeric"}).format(now):"";
  if(!ready||loading)return <div className="preloader" role="status" aria-live="polite"><div className="monogram large" aria-hidden="true">c<span>↗</span></div><div className="loader-rule"/><span className="loader-number">{String(progress).padStart(3,"0")}<small>%</small></span><p>Menyiapkan jurnal perjalanan</p></div>;
  return <div ref={root} className={`journal ${form.step==="summary"?"summary-view":""}`} onClick={clickMotion}>
    <Ambient reduced={reduced}/><a className="skip-link" href="#step-heading">Lewati ke formulir</a>
    <header className="site-header"><a href="#" className="brand" aria-label="Caizsel, kembali ke halaman awal" onClick={e=>{e.preventDefault();if(!busy)go(validIdentity(form.identity)?"home":"identity");}}><span className="monogram" aria-hidden="true">c<span>↗</span></span><span>caizsel<span className="brand-dot">.</span></span></a><span className="header-caption">A little journal, a personal journey.</span><button type="button" className="theme-toggle" onClick={themeToggle} aria-label={`Aktifkan tema ${theme==="dark"?"terang":"gelap"}`} title={`Tema ${theme==="dark"?"terang":"gelap"}`} data-motion="true">{theme==="dark"?<Sun size={20}/>:<Moon size={20}/>}</button></header>
    {storageWarning&&<div role="status" className="storage-warning"><AlertCircle size={17} aria-hidden="true"/>{storageWarning}</div>}
    <main className="journal-layout">
      <aside className={`story-side ${isQuestion?"question-story":""} ${form.step==="summary"?"summary-story":""}`} aria-label="Jurnal perjalanan Solo">
        <div className="edition"><span className="tiny-line"/>Solo travel journal<span className="edition-no">Vol. 01</span></div>
        <h2 className="story-title">Solo,<br/>dengan <span>caramu.</span></h2>
        <p className="story-description">Kota penuh cerita.<br/>Perjalanan yang dimulai dari dirimu.</p>
        <Parallax reduced={reduced}><figure className="destination-card"><div className="photo-corner" aria-hidden="true"/><img src="/solo-pendopo.webp" alt="Pendopo Pura Mangkunegaran, Surakarta" width="1600" height="613" fetchPriority="high"/><div className="photo-overlay"/><div className="photo-caption"><MapPin size={15} aria-hidden="true"/><span>Surakarta, Jawa Tengah</span><ArrowUpRight size={18} aria-hidden="true"/></div><div className="travel-stamp" aria-hidden="true"><span>Jelajah pelan</span><Compass size={30} strokeWidth={1}/><span>Kenang lama</span></div></figure></Parallax>
        <div className="coordinates"><span>7°34′ S · 110°49′ E</span><span>Indonesia / IDN</span></div>
        {isQuestion&&<div className="side-progress"><p><span>Rute ceritamu</span><strong>{String(index+1).padStart(2,"0")}<span> / 06</span></strong></p><RouteProgress active={index}/><p className="route-current">{questions[form.step as QuestionId].short}</p></div>}
        <div className="guide-signoff"><span className="guide-initial" aria-hidden="true">C</span><div><span>Ditemani {config.guideName}</span><small>Your local storyteller</small></div><span className="signoff-dash"/></div>
      </aside>
      <section key={form.step} ref={panel} className="form-panel" aria-busy={busy} inert={busy}>
        {form.step==="identity"&&<>
          <div className="step-eyebrow"><span className="eyebrow-dot"/>Sebelum cerita dimulai<span>01 — Hello</span></div>
          <h1 id="step-heading" tabIndex={-1} data-step-heading aria-label="Kenalan dulu."><span data-scramble aria-hidden="true">Kenalan dulu.</span></h1><p className="panel-description">Perjalanan personal dimulai dengan sebuah nama. Boleh tahu siapa kamu?</p>
          <form className="identity-form" onSubmit={e=>{e.preventDefault();if(validIdentity(form.identity)&&!busy)go("home",{intro:true});}} noValidate>
            <div className="field-group stagger-in"><label htmlFor="client-name">Nama kamu <span className="required-dot" aria-hidden="true">*</span></label><input id="client-name" autoComplete="name" placeholder="Nama yang ingin kamu ceritakan" value={form.identity.name} onChange={e=>update(s=>({...s,identity:{...s.identity,name:e.target.value}}))} onBlur={()=>setTouched(s=>({...s,name:true}))} required aria-invalid={touched.name&&!validName(form.identity.name)} aria-describedby={touched.name&&!validName(form.identity.name)?"name-error":"name-help"}/>{touched.name&&!validName(form.identity.name)?<p id="name-error" className="field-error" role="alert">Gunakan minimal 2 huruf. Spasi, tanda hubung, dan apostrof diperbolehkan.</p>:<p id="name-help" className="field-helper">Biar sapaan perjalanannya terasa lebih dekat.</p>}</div>
            <div className="field-group stagger-in"><label htmlFor="client-email">Email <span className="optional">(opsional)</span></label><input id="client-email" type="email" inputMode="email" autoComplete="email" placeholder="kamu@email.com" value={form.identity.email} onChange={e=>update(s=>({...s,identity:{...s.identity,email:e.target.value}}))} onBlur={()=>setTouched(s=>({...s,email:true}))} aria-invalid={touched.email&&!validEmail(form.identity.email)} aria-describedby={touched.email&&!validEmail(form.identity.email)?"email-error":undefined}/>{touched.email&&!validEmail(form.identity.email)&&<p id="email-error" role="alert" className="field-error">Format email belum valid. Contoh: nama@email.com</p>}</div>
            <MotionButton type="submit" className="primary full-width" disabled={!validIdentity(form.identity)||busy} reduced={reduced}>Masuk ke perjalanan<ArrowUpRight size={20} aria-hidden="true"/></MotionButton>
            <p className="identity-validation">{validIdentity(form.identity)?"Siap berkenalan. Lanjutkan perjalananmu.":"Isi nama minimal 2 huruf. Email boleh dikosongkan."}</p>
          </form>
          <div className="privacy-note"><ShieldCheck size={19} aria-hidden="true"/><p>{sessionHelp}</p></div>
          <div className="form-footnote"><span>Dirancang untuk perjalananmu.</span><span className="date-stamp">{dateStamp}</span></div>
        </>}
        {form.step==="home"&&<div className="home-content"><div className="step-eyebrow"><span className="eyebrow-dot"/>Cerita kita mulai di sini<span>Solo / IDN</span></div><div className="hello-compass" aria-hidden="true"><Compass size={42} strokeWidth={1}/><span>Selamat datang</span></div><h1 id="step-heading" tabIndex={-1} data-step-heading data-greeting>Halo, {titleCase(form.identity.name)}! Good {greeting(now?.getHours()??12)}!</h1><p className="panel-description">Aku {config.guideName}, siap menyusun itinerary terbaikmu.</p><div className="home-route"><span>Anggaran</span><span className="home-route-line"/><MapPin size={18} aria-hidden="true"/><span className="home-route-line"/><span>Preferensi</span></div><p className="home-note">Enam pertanyaan kecil untuk perjalanan yang lebih kamu banget.</p><MotionButton className="primary full-width" reduced={reduced} onClick={()=>go("1A")}>Mulai<ArrowRight size={20} aria-hidden="true"/></MotionButton><div className="privacy-note"><ShieldCheck size={19} aria-hidden="true"/><p>{sessionHelp}</p></div></div>}
        {isQuestion&&<form noValidate onSubmit={next}>
          <div className="step-eyebrow"><span className="eyebrow-dot"/>{questions[form.step as QuestionId].section}<span>{form.step} / 6 pertanyaan</span></div>
          <div className="mobile-route"><RouteProgress active={index}/></div>
          <h1 id="step-heading" tabIndex={-1} data-step-heading aria-label={questions[form.step as QuestionId].title}><span data-scramble aria-hidden="true">{questions[form.step as QuestionId].title}</span></h1><p className="panel-description">{questions[form.step as QuestionId].description}</p>
          <Question state={form} update={update} id={form.step as QuestionId} reduced={reduced} notice={notice} setNotice={setNotice}/>
          <div className="field-group notes-group"><label htmlFor={`notes-${form.step}`}>Catatan / masukan <span className="optional">(opsional)</span></label><textarea id={`notes-${form.step}`} rows={2} maxLength={250} placeholder="Ada hal kecil yang perlu aku tahu?" value={form.notes[form.step as QuestionId]} onChange={e=>{const id=form.step as QuestionId;update(s=>({...s,notes:{...s.notes,[id]:e.target.value}}));}}/><span className="character-count">{form.notes[form.step as QuestionId].length}/250</span></div>
          <p id="answer-help" className={`validation-hint ${isValid(form,form.step as QuestionId)?"is-valid":""}`} aria-live="polite">{isValid(form,form.step as QuestionId)?<><Check size={16} aria-hidden="true"/>Jawaban siap. Kamu bisa melanjutkan.</>:<><span className="hint-dot"/>{validationHint(form,form.step as QuestionId)}</>}</p>
          <div className="navigation"><MotionButton type="button" className="secondary" onClick={back} reduced={reduced}><ArrowLeft size={18} aria-hidden="true"/>Kembali</MotionButton><MotionButton type="submit" className="primary" disabled={!isValid(form,form.step as QuestionId)||busy} aria-describedby="answer-help" reduced={reduced}>{form.editing?"Simpan perubahan":"Lanjut"}<ArrowRight size={18} aria-hidden="true"/></MotionButton></div>
          <div className="question-footnote">{form.editing?"Perubahan disimpan ke ringkasanmu.":"Tidak perlu terburu-buru. Ini perjalananmu."}<span>{String(index+1).padStart(2,"0")} / 06</span></div>
        </form>}
        {form.step==="summary"&&<>
          <div className="step-eyebrow"><span className="eyebrow-dot"/>Satu langkah menuju Solo<span>Siap ditinjau</span></div><h1 id="step-heading" tabIndex={-1} data-step-heading aria-label="Cerita perjalananmu."><span data-scramble aria-hidden="true">Cerita perjalananmu.</span></h1><p className="panel-description">Cek sekali lagi. Semua hal kecil ini membantu {config.guideName} menyusun itinerary untukmu.</p>
          <div className="boarding-pass"><div className="pass-heading"><div><Ticket size={22} aria-hidden="true"/><span>Trip preference pass</span></div><span>SOLO / IDN</span></div><div className="pass-identity"><span className="pass-label">Nama traveler</span><strong>{form.identity.name}</strong><span>{form.identity.email.trim()||"Email: Tidak diisi"}</span>{form.filledAt&&<span className="pass-date">Diisi: {formatFilledAt(form.filledAt)}</span>}</div><div className="ticket-perforation"/>
            {questionIds.map(id=><div className={`summary-item ${!isValid(form,id)?"needs-answer":""}`} key={id}><div className="summary-item-top"><span className="summary-code">{id}</span><span>{questions[id].short}</span><button type="button" className="edit-button" onClick={()=>go(id,{editing:id})} aria-label={`Ubah ${id} ${questions[id].short}`}><PenLine size={14} aria-hidden="true"/>Ubah</button></div><p>{answerText(form,id)}</p><p className="summary-note">Catatan: {form.notes[id].trim()||"—"}</p></div>)}
            <div className="pass-bottom"><div className="barcode" aria-hidden="true"/><span>Disusun bersamamu, untukmu.</span><Compass size={22} aria-hidden="true"/></div>
          </div>
          {!allValid(form)&&<p className="field-error" role="status">Ada jawaban yang perlu diisi ulang. Pilih Ubah pada item yang ditandai sebelum Share.</p>}
          {form.shared&&<div className="share-status" role="status"><CheckCheck size={24} aria-hidden="true"/><div><strong>Formulir siap dikirim</strong><p>Terima kasih sudah berbagi ceritamu.</p><p>Tekan Kirim di WhatsApp untuk mengirim formulir ke guide.</p></div></div>}
          <div className="share-actions">{canShare?<a data-motion="true" className="button primary full-width" href={whatsappUrl(form)} target="_blank" rel="noopener noreferrer" onClick={()=>setForm(s=>({...s,shared:true}))}>Share Formulir<Send size={19} aria-hidden="true"/><span className="button-shine" aria-hidden="true"/></a>:<button className="button primary full-width" disabled>Share Formulir<Send size={19} aria-hidden="true"/></button>}<MotionButton type="button" className="secondary full-width" disabled={!canShare} reduced={reduced} onClick={copyText}><Copy size={18} aria-hidden="true"/>Salin teks</MotionButton></div>
          <p className="share-instructions">WhatsApp terbuka dengan pesan siap dikirim. Guide menerima formulir setelah kamu menekan Kirim di WhatsApp.</p>
          {manualCopy&&<div className="manual-copy"><label htmlFor="manual-text">Salin manual</label><p>Pilih teks berikut, salin, lalu tempel di chat WhatsApp.</p><textarea id="manual-text" readOnly rows={12} value={whatsappText(form)} onFocus={e=>e.currentTarget.select()}/></div>}
          <div className="fallback-box"><a href={config.waFallback} target="_blank" rel="noopener noreferrer">Buka chat alternatif<ExternalLink size={16} aria-hidden="true"/></a><p>Salin teks formulir terlebih dahulu, lalu tempelkan ke chat alternatif.</p></div><div className="summary-bottom-actions"><button type="button" onClick={()=>go("2C")}><ArrowLeft size={16} aria-hidden="true"/>Kembali</button><button type="button" onClick={()=>go("identity",{reset:true})}><RotateCcw size={16} aria-hidden="true"/>Mulai ulang</button></div>
        </>}
      </section>
    </main>
    <footer className="site-footer"><span>© {now?.getFullYear()??2026} {config.guideName}</span><span>Made for meaningful miles.</span><a href="https://commons.wikimedia.org/wiki/File:Grand_Pendopo,_Mangkunegaran_Palace.jpg" target="_blank" rel="noopener noreferrer" title="Foto diperkecil, ditampilkan dengan crop dan overlay. Lisensi CC BY-SA 3.0.">Foto: Crisco 1492 · CC BY-SA 3.0<ExternalLink size={11} aria-hidden="true"/></a></footer>
    <div ref={curtain} className="slide-curtain" aria-hidden="true"/>
    <div ref={pixels} className="pixel-transition" style={{gridTemplateColumns:`repeat(${T.intro.columns},1fr)`} as CSSProperties} aria-hidden="true">{Array.from({length:T.intro.cells},(_,i)=><span key={i}/>)}</div>
    <div role="status" aria-live="polite" className={`toast ${toast?"visible":""}`}>{toast&&<>{toast.toLocaleLowerCase().includes("tidak")?<AlertCircle size={18} aria-hidden="true"/>:<Check size={18} aria-hidden="true"/>}{toast}</>}</div>
  </div>;
}

function stepIndex(step:Step){return ["identity","home",...questionIds,"summary"].indexOf(step);}
function validationHint(s:FormState,id:QuestionId){
  if(id==="1A")return s.lodging?"Pilih satu rentang anggaran penginapan.":"Pilih jenis penginapan dan satu rentang anggaran.";
  if(id==="1B")return s.mealBasis?"Pilih satu rentang anggaran konsumsi.":"Pilih basis konsumsi dan satu rentang anggaran.";
  if(id==="1C")return "Pilih satu rentang biaya harian lain.";
  if(s.preferences[id].method==="text")return "Isi jawaban ketik. Teks kosong atau spasi belum cukup.";
  return id==="2A"?"Pilih minimal satu opsi, atau gunakan Ketik jawaban.":"Pilih minimal satu chip, atau gunakan Ketik jawaban.";
}
function Question({state:s,update,id,reduced,notice,setNotice}:{state:FormState;update:Update;id:QuestionId;reduced:boolean;notice:string;setNotice:(text:string)=>void}){
  const pref=(id.startsWith("2")?s.preferences[id as PreferenceId]:null);
  const changePref=(change:(p:Preference)=>Preference)=>{update(state=>({...state,preferences:{...state.preferences,[id]:change(state.preferences[id as PreferenceId])}}));};
  return <div className="question-content">
    {id==="1A"&&<><fieldset><legend>Jenis penginapan</legend><div className="lodging-selector">{lodgingKinds.map(kind=><button type="button" data-motion="true" aria-pressed={s.lodging===kind} key={kind} onClick={()=>{const previous=s.lodging;update(state=>changeLodging(state,s.lodging===kind?"":kind));if(previous)setNotice("Jenis penginapan berubah. Rentang 1A dan seluruh jawaban 2A, termasuk draft ketik, direset. Pilih kembali.");}}>{kind}{s.lodging===kind&&<Check size={14} aria-hidden="true"/>}</button>)}</div></fieldset>{s.lodging?<><p className="budget-unit">{s.lodging==="Vila"?"Solo Raya, mis. Tawangmangu · per unit / malam":"Per kamar / malam"}</p><div className="option-stack" role="group" aria-label="Rentang anggaran penginapan">{lodgingRanges[s.lodging].map((range,i)=><OptionCard key={letters[i]} letter={letters[i]} title={formatRange(range)} detail={s.lodging==="Vila"?"per unit / malam":"per kamar / malam"} selected={s.lodgingRange===letters[i]} onClick={()=>update(state=>({...state,lodgingRange:state.lodgingRange===letters[i]?null:letters[i]}))} reduced={reduced}/>)}</div></>:<div className="choose-first"><Compass size={25} strokeWidth={1.2} aria-hidden="true"/><p>Pilih tempat menginapmu.<br/><span>Rentang anggarannya akan muncul di sini.</span></p></div>}<p className="price-reference">Acuan harga Surakarta / Solo, Jawa Tengah.</p></>}
    {id==="1B"&&<><fieldset><legend>Basis konsumsi</legend><div className="segmented-control">{mealBases.map(basis=><button type="button" data-motion="true" aria-pressed={s.mealBasis===basis} key={basis} onClick={()=>{const previous=s.mealBasis;update(state=>changeMealBasis(state,state.mealBasis===basis?"":basis));if(previous)setNotice("Basis konsumsi berubah. Rentang 1B direset; pilih rentang kembali.");}}>{basis}{s.mealBasis===basis&&<Check size={15} aria-hidden="true"/>}</button>)}</div></fieldset>{s.mealBasis?<div className="option-stack" role="group" aria-label="Rentang anggaran konsumsi">{mealRanges[s.mealBasis].map((range,i)=><OptionCard key={letters[i]} letter={letters[i]} title={formatRange(range)} detail={`${s.mealBasis} / orang`} selected={s.mealRange===letters[i]} onClick={()=>update(state=>({...state,mealRange:state.mealRange===letters[i]?null:letters[i]}))} reduced={reduced}/>)}</div>:<div className="choose-first"><p>Pilih basis konsumsi untuk melihat rentang anggaran.</p></div>}<p className="price-reference">Anggaran konsumsi untuk satu orang.</p></>}
    {id==="1C"&&<><div className="option-stack" role="group" aria-label="Rentang biaya harian lain">{dailyRanges.map((range,i)=><OptionCard key={letters[i]} letter={letters[i]} title={formatRange(range)} detail="per orang / hari" selected={s.dailyRange===letters[i]} onClick={()=>update(state=>({...state,dailyRange:state.dailyRange===letters[i]?null:letters[i]}))} reduced={reduced}/>)}</div><p className="price-reference">Di luar penginapan & konsumsi. Maksimal Rp500.000/orang/hari.</p></>}
    {pref&&<><fieldset><legend className="sr-only">Metode menjawab</legend><div className="segmented-control answer-method">{([{value:"options",label:"Pilih opsi",icon:ListChecks},{value:"text",label:"Ketik jawaban",icon:PenLine}] as const).map(method=><button type="button" key={method.value} data-motion="true" aria-pressed={pref.method===method.value} onClick={()=>changePref(p=>({...p,method:method.value}))}><method.icon size={17} aria-hidden="true"/>{method.label}</button>)}</div></fieldset><p className="preference-help">{preferenceHelp}</p>
      {pref.method==="text"?<div className="field-group typed-answer"><label htmlFor={`answer-${id}`}>Jawabanmu <span className="required-dot" aria-hidden="true">*</span></label><textarea id={`answer-${id}`} rows={4} maxLength={250} value={pref.text} placeholder={questions[id].placeholder} aria-describedby={`typed-help-${id}`} onChange={e=>changePref(p=>({...p,text:e.target.value}))}/><span className="character-count">{pref.text.length}/250</span><p id={`typed-help-${id}`} className="field-helper">Jawaban ketik digunakan selama metode ini aktif.</p></div>:id==="2A"?<>{s.lodging?<><p className="budget-unit">Penginapan pilihanmu: {s.lodging}</p><div className="option-stack" role="group" aria-label="Hal yang dihindari di penginapan">{avoidOptions[s.lodging].map((option,i)=><OptionCard key={letters[i]} letter={letters[i]} title={option} selected={pref.selected.includes(letters[i])} onClick={()=>changePref(p=>({...p,selected:toggle(p.selected,letters[i])}))} reduced={reduced}/>)}</div></>:<p className="field-error">Lengkapi jenis penginapan di 1A terlebih dahulu melalui ringkasan.</p>}</>:<div className="category-stack" role="group" aria-label={questions[id].short}>{preferenceGroups[id as "2B"|"2C"].map(group=><div key={group.letter} className={`category-group ${pref.categories.includes(group.letter)?"category-active":""}`}><OptionCard letter={group.letter} title={group.label} detail={pref.groups[group.letter].length?`${pref.groups[group.letter].length} pilihan`:undefined} selected={pref.categories.includes(group.letter)} expanded={pref.categories.includes(group.letter)} onClick={()=>changePref(p=>toggleCategory(p,group.letter))} reduced={reduced}/>{pref.categories.includes(group.letter)&&<div className="chip-list" role="group" aria-label={`Sub-pilihan ${group.label}`}>{group.chips.map(chip=><button key={chip} type="button" data-motion="true" className={`chip ${pref.groups[group.letter].includes(chip)?"is-selected":""}`} aria-pressed={pref.groups[group.letter].includes(chip)} onClick={()=>changePref(p=>({...p,groups:{...p.groups,[group.letter]:toggle(p.groups[group.letter],chip)}}))}>{pref.groups[group.letter].includes(chip)&&<Check size={14} aria-hidden="true"/>}{chip}</button>)}{!pref.groups[group.letter].length&&<p className="chip-helper">Pilih minimal satu chip pada kategori yang kamu perlukan.</p>}</div>}</div>)}</div>}
    </>}
    {notice&&<p className="reset-notice" role="status"><AlertCircle size={17} aria-hidden="true"/>{notice}</p>}
  </div>;
}
