"use client";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { T } from "@/lib/tokens";

export function Ambient({reduced}:{reduced:boolean}){
  const canvas=useRef<HTMLCanvasElement>(null);
  useEffect(()=>{
    if(reduced||!canvas.current)return;
    const el=canvas.current,ctx=el.getContext("2d");if(!ctx)return;
    let width=0,height=0,frame=0,last=0,color="";
    let dots:{x:number;y:number;r:number;v:number}[]=[];
    const resize=()=>{width=innerWidth;height=innerHeight;const dpr=Math.min(devicePixelRatio||1,T.ambient.dprMax);el.width=width*dpr;el.height=height*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);dots=Array.from({length:width<768?T.ambient.mobileCount:T.ambient.count},()=>({x:Math.random()*width,y:Math.random()*height,r:Math.random()*T.ambient.radius+0.3,v:Math.random()*T.ambient.speed+T.ambient.speed}));readColor();};
    const readColor=()=>{color=getComputedStyle(document.documentElement).getPropertyValue("--gold").trim();};
    const draw=(time:number)=>{frame=requestAnimationFrame(draw);if(time-last<1000/T.ambient.fps)return;const dt=Math.min(time-last,T.ambient.dtMax);last=time;ctx.clearRect(0,0,width,height);ctx.fillStyle=color;ctx.globalAlpha=T.ambient.alpha;for(const d of dots){d.y-=d.v*dt;if(d.y<0)d.y=height;ctx.beginPath();ctx.arc(d.x,d.y,d.r,0,Math.PI*2);ctx.fill();}};
    const visibility=()=>{cancelAnimationFrame(frame);if(!document.hidden){last=performance.now();frame=requestAnimationFrame(draw);}};
    const observer=new MutationObserver(readColor);observer.observe(document.documentElement,{attributes:true,attributeFilter:["data-theme"]});
    resize();visibility();addEventListener("resize",resize);document.addEventListener("visibilitychange",visibility);
    return()=>{cancelAnimationFrame(frame);removeEventListener("resize",resize);document.removeEventListener("visibilitychange",visibility);observer.disconnect();ctx.clearRect(0,0,width,height);};
  },[reduced]);
  return <canvas ref={canvas} className="ambient" aria-hidden="true"/>;
}

export function Parallax({children,reduced}:{children:React.ReactNode;reduced:boolean}){
  const ref=useRef<HTMLDivElement>(null);
  useEffect(()=>{
    const el=ref.current;if(!el||reduced||!matchMedia("(hover: hover) and (pointer: fine)").matches)return;
    const x=gsap.quickTo(el,"x",{duration:T.ambient.duration,ease:T.out}),y=gsap.quickTo(el,"y",{duration:T.ambient.duration,ease:T.out});
    const move=(e:PointerEvent)=>{x((e.clientX/innerWidth-.5)*T.ambient.parallax);y((e.clientY/innerHeight-.5)*T.ambient.parallax);};
    const leave=()=>{x(0);y(0);};
    window.addEventListener("pointermove",move);document.addEventListener("pointerleave",leave);
    return()=>{window.removeEventListener("pointermove",move);document.removeEventListener("pointerleave",leave);x.tween.kill();y.tween.kill();gsap.set(el,{clearProps:"transform"});};
  },[reduced]);
  return <div ref={ref}>{children}</div>;
}
