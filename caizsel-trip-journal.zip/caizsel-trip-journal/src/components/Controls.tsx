"use client";
import { useRef, type ButtonHTMLAttributes, type PointerEvent } from "react";
import gsap from "gsap";
import { useGSAP } from "@gsap/react";
import { Check, ArrowUpRight, ChevronDown } from "lucide-react";
import { T } from "@/lib/tokens";

export function MotionButton({children,className="",reduced=false,...props}:ButtonHTMLAttributes<HTMLButtonElement>&{reduced?:boolean}){
  const ref=useRef<HTMLButtonElement>(null);
  const {contextSafe}=useGSAP({scope:ref});
  const move=contextSafe((e:PointerEvent<HTMLButtonElement>)=>{if(reduced||!matchMedia("(hover:hover) and (pointer:fine)").matches)return;const r=e.currentTarget.getBoundingClientRect();gsap.to(e.currentTarget,{x:gsap.utils.clamp(-T.magnetic.max,T.magnetic.max,(e.clientX-r.left-r.width/2)*T.magnetic.strength),y:gsap.utils.clamp(-T.magnetic.max,T.magnetic.max,(e.clientY-r.top-r.height/2)*T.magnetic.strength),duration:T.magnetic.duration,ease:T.out,overwrite:true});});
  const leave=contextSafe(()=>{gsap.to(ref.current,{x:0,y:0,duration:reduced?T.reduced:T.magnetic.duration,ease:T.spring,overwrite:true});});
  return <button ref={ref} data-motion="true" className={`button ${className}`} onPointerMove={move} onPointerLeave={leave} {...props}>{children}<span className="button-shine" aria-hidden="true"/></button>;
}
export function OptionCard({letter,title,detail,selected,onClick,expanded,reduced}:{letter:string;title:string;detail?:string;selected:boolean;onClick:()=>void;expanded?:boolean;reduced:boolean}){
  const ref=useRef<HTMLButtonElement>(null);
  useGSAP(()=>{const path=ref.current?.querySelector(".selection-tick path");if(path)gsap.to(path,{strokeDashoffset:selected?0:24,duration:reduced?T.reduced:T.click.check,ease:T.out,overwrite:true});},{scope:ref,dependencies:[selected,reduced]});
  return <button ref={ref} type="button" data-motion="true" className={`option-card ${selected?"is-selected":""}`} aria-label={`${letter}. ${title}${detail?` — ${detail}`:""}`} aria-pressed={selected} aria-expanded={expanded} onClick={onClick}>
    <span className="option-letter" aria-hidden="true">{letter}</span><span className="option-copy"><span className="option-title reveal-option">{title}</span>{detail&&<span className="option-detail">{detail}</span>}</span>
    <span className="selection-tick" aria-hidden="true"><Check size={17}/></span>{expanded!==undefined&&<ChevronDown size={18} className={`category-chevron ${expanded?"open":""}`} aria-hidden="true"/>}
  </button>;
}
export function RouteProgress({active}:{active:number}){
  return <div className="route-progress" role="img" aria-label={`Langkah ${Math.min(active+1,6)} dari 6 pertanyaan`}>
    <svg viewBox="0 0 360 28" fill="none" aria-hidden="true"><path d="M12 14H348" stroke="var(--line)" strokeWidth="1.5" strokeDasharray="2 6"/>{[12,79,146,213,280,348].map((x,i)=><g key={x}><circle cx={x} cy="14" r={active===i?10:5} fill={i<active?"var(--gold-text)":"var(--bg)"} stroke={i<=active?"var(--gold-text)":"var(--muted)"} strokeWidth="1.5"/>{i<active&&<path d={`m${x-2.5} 14 1.8 1.8 3.4-3.4`} stroke="var(--bg)" strokeWidth="1.5"/>}{i===active&&<circle cx={x} cy="14" r="4" fill="var(--gold-text)"/>}</g>)}</svg>
    <div className="route-labels" aria-hidden="true"><span>Anggaran</span><ArrowUpRight size={14}/><span>Preferensi</span></div>
  </div>;
}
