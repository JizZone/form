/** Semua waktu (detik), easing, stagger, dan parameter gerak ada di sini. */
export const T = {
  ease: "power3.inOut", out: "expo.out", spring: "elastic.out(1, 0.65)", cssEase: "cubic-bezier(.16,1,.3,1)",
  slide: { exit: 0.1, enter: 0.22, curtain: 0.16, offset: 12, stagger: 0.035, maxStagger: 0.08 },
  intro: { cover: 0.29, uncover: 0.3, stagger: 0.003, columns: 12, cells: 96, scale: 0.85 },
  text: { duration: 0.24, stagger: 0.008, maxStagger: 0.09, blur: 4, offset: 14, optionY: 80, scramble: 0.18, charset: "·:+/○" },
  click: { duration: 0.16, ripple: 0.2, rippleAlpha: 0.2, rippleDiameter: 2, scale: 0.985, ring: 0.2, check: 0.2, shine: 0.2, haptic: 10 },
  magnetic: { duration: 0.18, strength: 0.08, max: 5 },
  theme: { duration: 0.46, fade: 0.16, fadeOpacity: 0.5, ease: "cubic-bezier(.65,0,.35,1)" },
  reduced: 0.01,
  ambient: { count: 19, mobileCount: 10, dprMax: 1.5, dtMax: 50, fps: 30, speed: 0.035, radius: 1.25, alpha: 0.18, parallax: 8, duration: 0.7, float: 4, floatDistance: 5, floatEase: "sine.inOut" },
  toast: 3.4,
} as const;
