import { config } from "../config";
import { avoidOptions, dailyRanges, formatRange, letters, lodgingKinds, lodgingRanges, mealBases, mealRanges, preferenceGroups, questionIds, type Letter, type LodgingKind, type MealBasis, type QuestionId } from "./data";

export const SESSION_KEY = "caizsel.trip.v1";
export const THEME_KEY = "caizsel.theme";
export type Step = "identity" | "home" | QuestionId | "summary";
export type PreferenceId = "2A" | "2B" | "2C";
export type Preference = { method:"options"|"text"; text:string; selected:Letter[]; categories:Letter[]; groups:Record<Letter,string[]> };
export type FormState = {
  version:1; identity:{name:string;email:string}; step:Step; introSeen:boolean;
  lodging:LodgingKind|""; lodgingRange:Letter|null; mealBasis:MealBasis|""; mealRange:Letter|null; dailyRange:Letter|null;
  preferences:Record<PreferenceId,Preference>; notes:Record<QuestionId,string>;
  editing:QuestionId|null; shared:boolean; filledAt:string|null;
};
export const emptyPreference = ():Preference => ({method:"options",text:"",selected:[],categories:[],groups:{A:[],B:[],C:[]}});
export function initialState():FormState {
  return {version:1,identity:{name:"",email:""},step:"identity",introSeen:false,lodging:"",lodgingRange:null,mealBasis:"",mealRange:null,dailyRange:null,preferences:{"2A":emptyPreference(),"2B":emptyPreference(),"2C":emptyPreference()},notes:{"1A":"","1B":"","1C":"","2A":"","2B":"","2C":""},editing:null,shared:false,filledAt:null};
}
export function validName(name:string) {
  const value=name.trim();
  return /^[\p{L}\p{M}\s'’\-]+$/u.test(value) && (value.match(/\p{L}/gu)?.length ?? 0)>=2;
}
export function validEmail(email:string) {
  const value=email.trim();
  if (!value) return true;
  if(value.length>254 || /\s/.test(value)) return false;
  const parts=value.split("@");
  if(parts.length!==2 || parts[0].length>64 || !parts[0] || !parts[1])return false;
  if(!/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/.test(parts[0]) || parts[0].startsWith(".") || parts[0].endsWith(".") || parts[0].includes(".."))return false;
  const labels=parts[1].split(".");
  return labels.length>=2 && labels.every(label=>/^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/.test(label)) && labels.at(-1)!.length>=2;
}
export const validIdentity=(identity:FormState["identity"])=>validName(identity.name)&&validEmail(identity.email);
export function titleCase(name:string){return name.trim().toLocaleLowerCase("id-ID").replace(/(^|[\s\-’'])[\p{L}\p{M}]/gu,v=>v.toLocaleUpperCase("id-ID"));}
export function greeting(hour:number){return hour>=4&&hour<12?"morning":hour>=12&&hour<18?"afternoon":"evening";}
export function isValid(state:FormState,id:QuestionId):boolean {
  if(id==="1A")return !!state.lodging && letters.includes(state.lodgingRange as Letter);
  if(id==="1B")return !!state.mealBasis && letters.includes(state.mealRange as Letter);
  if(id==="1C")return letters.includes(state.dailyRange as Letter);
  const p=state.preferences[id];
  if(p.method==="text")return !!p.text.trim() && p.text.length<=250 && (id!=="2A" || !!state.lodging);
  if(id==="2A")return !!state.lodging && p.selected.length>0;
  return preferenceGroups[id].some(g=>p.categories.includes(g.letter)&&p.groups[g.letter].length>0);
}
export const allValid=(s:FormState)=>validIdentity(s.identity)&&questionIds.every(id=>isValid(s,id));
export const toggle=<T,>(items:T[],item:T)=>items.includes(item)?items.filter(x=>x!==item):[...items,item];
export function changeLodging(s:FormState,kind:LodgingKind|""):FormState {
  if(s.lodging===kind)return s;
  return {...s,lodging:kind,lodgingRange:null,preferences:{...s.preferences,"2A":emptyPreference()},shared:false,filledAt:null};
}
export function changeMealBasis(s:FormState,basis:MealBasis|""):FormState {
  return s.mealBasis===basis?s:{...s,mealBasis:basis,mealRange:null,shared:false,filledAt:null};
}
export function toggleCategory(p:Preference,letter:Letter):Preference {
  return {...p,categories:toggle(p.categories,letter),groups:{...p.groups,[letter]:p.categories.includes(letter)?[]:p.groups[letter]}};
}
export function answerText(s:FormState,id:QuestionId):string {
  if(!isValid(s,id))return "Perlu diisi ulang";
  if(id==="1A")return `${s.lodging} · ${s.lodgingRange}. ${formatRange(lodgingRanges[s.lodging as LodgingKind][letters.indexOf(s.lodgingRange!)])}/malam${s.lodging==="Vila"?" per unit":" per kamar"}`;
  if(id==="1B")return `${s.mealRange}. ${formatRange(mealRanges[s.mealBasis as MealBasis][letters.indexOf(s.mealRange!)])} ${s.mealBasis} per orang`;
  if(id==="1C")return `${s.dailyRange}. ${formatRange(dailyRanges[letters.indexOf(s.dailyRange!)])}/orang/hari`;
  const p=s.preferences[id];
  if(p.method==="text")return p.text.trim();
  if(id==="2A")return letters.filter(l=>p.selected.includes(l)).map(l=>`${l}. ${avoidOptions[s.lodging as LodgingKind][letters.indexOf(l)]}`).join("; ");
  return preferenceGroups[id].filter(g=>p.categories.includes(g.letter)&&p.groups[g.letter].length).map(g=>`${g.output} [${g.chips.filter(c=>p.groups[g.letter].includes(c)).join(", ")}]`).join("; ");
}
export function formatFilledAt(iso:string){return new Intl.DateTimeFormat("id-ID",{dateStyle:"medium",timeStyle:"short"}).format(new Date(iso));}
export function whatsappText(s:FormState):string {
  if(!allValid(s)||!s.filledAt)return "";
  const note=(id:QuestionId)=>s.notes[id].trim()||"—";
  const rangeA=formatRange(lodgingRanges[s.lodging as LodgingKind][letters.indexOf(s.lodgingRange!)]);
  const rangeB=formatRange(mealRanges[s.mealBasis as MealBasis][letters.indexOf(s.mealRange!)]);
  return `FORMULIR PREFERENSI TRIP\nNama: ${s.identity.name.trim()} | Email: ${s.identity.email.trim()||"Tidak diisi"} | Diisi: ${formatFilledAt(s.filledAt)}\n\n1. ANGGARAN\nA. Penginapan (${s.lodging}): ${s.lodgingRange}. ${rangeA}/malam ${s.lodging==="Vila"?"per unit":"per kamar"} — Catatan: ${note("1A")}\nB. Konsumsi (${s.mealBasis}): ${s.mealRange}. ${rangeB} per orang — Catatan: ${note("1B")}\nC. Biaya harian lain: ${s.dailyRange}. ${formatRange(dailyRanges[letters.indexOf(s.dailyRange!)])}/orang/hari — Catatan: ${note("1C")}\n\n2. SUKA / TIDAK SUKA\nA. Hindari di penginapan: ${answerText(s,"2A")} — Catatan: ${note("2A")}\nB. Konsumsi: ${answerText(s,"2B")} — Catatan: ${note("2B")}\nC. Disukai: ${answerText(s,"2C")} — Catatan: ${note("2C")}`;
}
export const whatsappUrl=(s:FormState)=>`https://wa.me/${config.waNumber}?text=${encodeURIComponent(whatsappText(s))}`;

/** Parse hanya schema yang dikenal; state korup tidak dapat melewati validasi. */
export function restoreState(raw:string):FormState {
  const v=JSON.parse(raw);
  if(!v||v.version!==1||typeof v.identity?.name!=="string"||typeof v.identity?.email!=="string")throw new Error("Invalid session");
  const s=initialState();
  s.identity={name:v.identity.name,email:v.identity.email};
  const steps:Step[]=["identity","home",...questionIds,"summary"];
  s.step=steps.includes(v.step)?v.step:"identity";
  s.introSeen=v.introSeen===true;
  s.lodging=lodgingKinds.includes(v.lodging)?v.lodging:"";
  s.mealBasis=mealBases.includes(v.mealBasis)?v.mealBasis:"";
  for(const key of ["lodgingRange","mealRange","dailyRange"] as const)s[key]=letters.includes(v[key])?v[key]:null;
  if(!s.lodging)s.lodgingRange=null;
  if(!s.mealBasis)s.mealRange=null;
  for(const id of questionIds)s.notes[id]=typeof v.notes?.[id]==="string"?v.notes[id].slice(0,250):"";
  for(const id of ["2A","2B","2C"] as const){
    const p=v.preferences?.[id]; if(!p)continue;
    const dest=s.preferences[id];
    dest.method=p.method==="text"?"text":"options";
    dest.text=typeof p.text==="string"?p.text.slice(0,250):"";
    dest.selected=letters.filter(l=>Array.isArray(p.selected)&&p.selected.includes(l));
    dest.categories=letters.filter(l=>Array.isArray(p.categories)&&p.categories.includes(l));
    if(id!=="2A") for(const g of preferenceGroups[id])dest.groups[g.letter]=dest.categories.includes(g.letter)?g.chips.filter(c=>Array.isArray(p.groups?.[g.letter])&&p.groups[g.letter].includes(c)):[];
  }
  if(!s.lodging)s.preferences["2A"]=emptyPreference();
  s.editing=questionIds.includes(v.editing)&&s.step===v.editing?v.editing:null;
  s.shared=v.shared===true;
  s.filledAt=typeof v.filledAt==="string"&&Number.isFinite(Date.parse(v.filledAt))?v.filledAt:null;
  if(!validIdentity(s.identity)){s.step="identity";s.editing=null;}
  return s;
}
