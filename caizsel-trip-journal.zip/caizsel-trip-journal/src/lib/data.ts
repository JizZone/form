export const letters = ["A", "B", "C"] as const;
export type Letter = typeof letters[number];
export const questionIds = ["1A", "1B", "1C", "2A", "2B", "2C"] as const;
export type QuestionId = typeof questionIds[number];
export const lodgingKinds = ["Hotel", "Homestay", "Vila", "Kos harian"] as const;
export type LodgingKind = typeof lodgingKinds[number];
export const mealBases = ["per 1x makan", "per hari"] as const;
export type MealBasis = typeof mealBases[number];
type Range = readonly [number, number];
export const lodgingRanges: Record<LodgingKind, readonly Range[]> = {
  "Kos harian": [[75000,125000],[125000,200000],[200000,300000]],
  Homestay: [[150000,250000],[250000,400000],[400000,650000]],
  Hotel: [[200000,400000],[400000,800000],[800000,1500000]],
  Vila: [[300000,700000],[700000,1500000],[1500000,3000000]],
};
export const mealRanges: Record<MealBasis, readonly Range[]> = {
  "per 1x makan": [[10000,25000],[25000,50000],[50000,100000]],
  "per hari": [[40000,80000],[80000,150000],[150000,300000]],
};
export const dailyRanges: readonly Range[] = [[50000,100000],[100000,250000],[250000,500000]];
export const avoidOptions: Record<LodgingKind, readonly string[]> = {
  "Kos harian": ["Kamar mandi luar/bersama", "Tanpa AC", "Tanpa Wi-Fi"],
  Homestay: ["Kamar mandi bersama", "Kamar berbagi dengan tamu lain", "Tanpa AC/water heater"],
  Hotel: ["Jauh dari pusat/wisata", "Tanpa sarapan", "Kamar smoking/tanpa lift"],
  Vila: ["Lokasi terpencil/akses sulit", "Tanpa dapur", "Sinyal/Wi-Fi lemah"],
};
export const preferenceGroups = {
  "2B": [
    { letter: "A", label: "Alergi", output: "Alergi", chips: ["Seafood", "Kacang", "Telur", "Susu", "Gluten"] },
    { letter: "B", label: "Diet/pantangan", output: "Diet", chips: ["Halal", "Vegetarian", "Vegan"] },
    { letter: "C", label: "Rasa", output: "Rasa", chips: ["Tidak pedas", "Tidak terlalu manis", "Tanpa santan"] },
  ],
  "2C": [
    { letter: "A", label: "Aktivitas", output: "Aktivitas", chips: ["Night ride", "Sunrise/sunset hunting", "Trekking ringan", "Keliling santai"] },
    { letter: "B", label: "Spot & foto", output: "Spot & foto", chips: ["Tempat estetik", "Alam & pemandangan", "Sejarah & budaya (keraton, batik)", "Pasar/jajanan lokal"] },
    { letter: "C", label: "Gaya trip", output: "Gaya trip", chips: ["Slow trip", "Padat jadwal", "Privat/sepi", "Ramai & hidup"] },
  ],
} as const;
export const questions: Record<QuestionId, {title:string; description:string; short:string; section:string; placeholder?:string}> = {
  "1A": {title:"Tempat pulang setelah berpetualang.",description:"Pilih jenis penginapan, lalu rentang yang nyaman buatmu.",short:"Penginapan",section:"01 / Anggaran"},
  "1B": {title:"Cerita enak dimulai dari meja makan.",description:"Tentukan basis konsumsi, lalu pilih rentang anggaranmu.",short:"Konsumsi",section:"01 / Anggaran"},
  "1C": {title:"Sisakan ruang untuk menjelajah.",description:"Biaya harian di luar penginapan & konsumsi: tiket wisata, transport lokal, parkir, dan lainnya.",short:"Biaya harian lain",section:"01 / Anggaran"},
  "2A": {title:"Istirahat nyaman, tanpa kompromi.",description:"Apa yang ingin kamu hindari di penginapan? Boleh pilih lebih dari satu.",short:"Hindari di penginapan",section:"02 / Suka & tidak suka",placeholder:"Contoh: Tidak ada yang dihindari, atau tulis kebutuhanmu."},
  "2B": {title:"Selera kecil, perhatian besar.",description:"Ceritakan alergi, pantangan, atau rasa yang perlu diperhatikan.",short:"Preferensi konsumsi",section:"02 / Suka & tidak suka",placeholder:"Contoh: Tidak ada alergi/pantangan atau preferensi rasa, atau tulis rincianmu."},
  "2C": {title:"Perjalanan yang terasa seperti kamu.",description:"Pilih hal yang kamu sukai. Inilah awal cerita perjalananmu.",short:"Hal yang disukai",section:"02 / Suka & tidak suka",placeholder:"Contoh: Tidak ada preferensi khusus, atau tulis hal yang kamu sukai."},
};
export const preferenceHelp = "Pilih opsi atau ketik jawabanmu. Jika tidak ada preferensi, tulis ‘Tidak ada’.";
export const sessionHelp = "Isianmu tersimpan sementara di tab ini. Share membuka WhatsApp dengan pesan siap dikirim; guide menerima setelah kamu menekan Kirim di WhatsApp.";
export function formatRange(range: Range) { return `Rp${range[0].toLocaleString("id-ID")}–${range[1].toLocaleString("id-ID")}`; }
