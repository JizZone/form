import TravelJournal from "@/components/TravelJournal";
export default function Page(){return <TravelJournal/>;}
