import type { Metadata } from "next";
import { T } from "@/lib/tokens";
import "./globals.css";

export const metadata:Metadata={title:"Caizsel — Solo, dengan caramu",description:"Jurnal preferensi trip bersama Caizsel. Ceritakan anggaran dan hal yang kamu sukai untuk perjalanan yang lebih personal."};
const themeScript=`(()=>{let t;try{t=localStorage.getItem('caizsel.theme')}catch{};document.documentElement.dataset.theme=t==='light'||t==='dark'?t:matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light'})()`;
export default function RootLayout({children}:Readonly<{children:React.ReactNode}>){
  return <html lang="id" suppressHydrationWarning style={{"--motion-click":`${T.click.duration}s`,"--motion-theme":`${T.theme.fade}s`,"--motion-check":`${T.click.check}s`,"--motion-ease":T.cssEase} as React.CSSProperties}>
    <head><script dangerouslySetInnerHTML={{__html:themeScript}}/><link rel="preload" href="/fonts/montserrat-600.woff" as="font" type="font/woff" crossOrigin="anonymous"/><link rel="preload" href="/fonts/jakarta-400.woff" as="font" type="font/woff" crossOrigin="anonymous"/></head>
    <body>{children}<noscript><p className="noscript">Aktifkan JavaScript untuk mengisi formulir preferensi perjalanan ini.</p></noscript></body>
  </html>;
}
