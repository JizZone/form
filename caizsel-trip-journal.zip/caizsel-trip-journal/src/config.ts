export const config = {
  guideName: "Caizsel",
  waNumber: "6287791891018",
  waFallback: "https://wa.me/message/USFW4S2RGFGKD1",
} as const;
