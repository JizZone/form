import {test} from "node:test";
import assert from "node:assert/strict";
import { allValid, answerText, changeLodging, changeMealBasis, greeting, initialState, isValid, restoreState, titleCase, toggle, toggleCategory, validEmail, validIdentity, validName, whatsappText, whatsappUrl } from "../src/lib/form";
import { avoidOptions, dailyRanges, letters, lodgingKinds, lodgingRanges, mealRanges, questionIds } from "../src/lib/data";

function complete(){
  const s=initialState();s.identity={name:"hERlin Élodie O’NEILL",email:""};s.lodging="Hotel";s.lodgingRange="B";s.mealBasis="per hari";s.mealRange="B";s.dailyRange="C";
  s.preferences["2A"].selected=["A","C"];
  s.preferences["2B"].categories=["A","C"];s.preferences["2B"].groups.A=["Seafood"];s.preferences["2B"].groups.C=["Tidak pedas","Tanpa santan"];
  s.preferences["2C"].categories=["A","B","C"];s.preferences["2C"].groups.A=["Night ride"];s.preferences["2C"].groups.B=["Spot invalid","Alam & pemandangan"];s.preferences["2C"].groups.C=["Slow trip"];
  s.filledAt="2026-10-28T08:30:00.000Z";s.step="summary";s.introSeen=true;return s;
}
test("nama Unicode, spasi, apostrof dan hubung; minimal dua huruf",()=>{
  for(const name of ["  Élodie O’Neill ","李 明","D'Arcy","Jean-Luc","A B","نورا","éa"])assert.equal(validName(name),true,name);
  for(const name of ["","  ","A","A--","123","Alex2","a@b"])assert.equal(validName(name),false,name);
  const s=initialState();s.identity.name="李明";assert.equal(validIdentity(s.identity),true);
});
test("email opsional, format valid dan domain",()=>{
  for(const email of ["","   ","alex+trip@example.co.id","o'neill@example.com"])assert.equal(validEmail(email),true,email);
  for(const email of ["x@","x@localhost","a..b@example.com","a@-x.com","a b@example.com","a@@b.com",".a@b.com","a@b..com"])assert.equal(validEmail(email),false,email);
});
test("sapaan tepat di seluruh batas waktu dan Title Case tidak mengubah identitas",()=>{
  for(const [hour,value] of [[0,"evening"],[3,"evening"],[4,"morning"],[11,"morning"],[12,"afternoon"],[17,"afternoon"],[18,"evening"],[23,"evening"]] as const)assert.equal(greeting(hour),value);
  assert.equal(titleCase("  hERlin ÉLODIE o’NEILL-jean  "),"Herlin Élodie O’Neill-Jean");
  const s=complete();titleCase(s.identity.name);assert.equal(s.identity.name,"hERlin Élodie O’NEILL");
});
test("semua jawaban wajib kosong; catatan tidak menggantikan anggaran",()=>{
  const s=initialState();for(const id of questionIds){s.notes[id]="Sudah menjawab lewat catatan";assert.equal(isValid(s,id),false,id);}assert.equal(allValid(s),false);
  s.lodging="Hotel";assert.equal(isValid(s,"1A"),false);s.lodgingRange="A";assert.equal(isValid(s,"1A"),true);s.lodgingRange=null;assert.equal(isValid(s,"1A"),false);
  s.mealBasis="per 1x makan";assert.equal(isValid(s,"1B"),false);s.mealRange="A";assert.equal(isValid(s,"1B"),true);
});
test("batal dan ganti opsi tidak mengunci opsi lain",()=>{
  assert.deepEqual(toggle(["A"],"A"),[]);assert.deepEqual(toggle(["A"],"B"),["A","B"]);
  const s=complete();s.preferences["2A"].selected=["A"];assert.ok(isValid(s,"2A"));s.preferences["2A"].selected=toggle(s.preferences["2A"].selected,"A");assert.equal(isValid(s,"2A"),false);
});
test("rentang harga dan dependensi jenis penginapan utuh",()=>{
  for(const kind of lodgingKinds){assert.equal(lodgingRanges[kind].length,3);assert.equal(avoidOptions[kind].length,3);lodgingRanges[kind].forEach((r,i)=>{assert.ok(r[0]<r[1]);if(i)assert.ok(r[0]>=lodgingRanges[kind][i-1][1]);});}
  assert.equal(dailyRanges[2][1],500000);assert.deepEqual(lodgingRanges["Kos harian"][0],[75000,125000]);assert.deepEqual(mealRanges["per hari"][2],[150000,300000]);
  const original=complete();original.preferences["2A"].text="draft";original.preferences["2A"].method="text";
  const next=changeLodging(original,"Vila");assert.equal(next.lodgingRange,null);assert.equal(next.preferences["2A"].text,"");assert.equal(next.preferences["2A"].selected.length,0);assert.equal(next.identity,original.identity);assert.equal(next.preferences["2B"],original.preferences["2B"]);assert.equal(next.mealRange,"B");assert.equal(isValid(next,"2A"),false);
  assert.equal(changeLodging(original,"Hotel"),original);
});
test("mengganti basis konsumsi hanya mereset rentang 1B",()=>{
  const s=complete(),next=changeMealBasis(s,"per 1x makan");assert.equal(next.mealRange,null);assert.equal(next.lodgingRange,"B");assert.equal(next.preferences,s.preferences);assert.equal(isValid(next,"1B"),false);
});
test("kategori tanpa chip tidak valid, pembatalan kategori menghapus chipnya saja",()=>{
  const s=complete();s.preferences["2B"].groups={A:[],B:[],C:[]};assert.equal(isValid(s,"2B"),false);
  s.preferences["2B"].groups.C=["Tidak pedas"];assert.equal(isValid(s,"2B"),true);assert.equal(answerText(s,"2B"),"Rasa [Tidak pedas]");
  const p=toggleCategory(s.preferences["2B"],"A");assert.deepEqual(p.groups.A,[]);assert.deepEqual(p.groups.C,["Tidak pedas"]);assert.equal(p.categories.includes("C"),true);
  const clear=toggleCategory(p,"C");assert.deepEqual(clear.groups.C,[]);
});
test("jawaban ketik wajib non-spasi, maks 250, draft metode tersimpan terpisah",()=>{
  const s=complete();for(const id of ["2A","2B","2C"] as const){const p=s.preferences[id];p.method="text";p.text=" \n ";assert.equal(isValid(s,id),false);p.text="Tidak ada";assert.equal(isValid(s,id),true);assert.equal(answerText(s,id),"Tidak ada");p.text="a".repeat(251);assert.equal(isValid(s,id),false);p.text="a".repeat(250);assert.equal(isValid(s,id),true);p.method="options";assert.equal(isValid(s,id),true);assert.equal(p.text.length,250);}
});
test("ringkasan dan WA memakai jawaban aktif, Rasa dan label kelompok 2C",()=>{
  const s=complete(),text=whatsappText(s);assert.ok(allValid(s));assert.match(text,/Nama: hERlin Élodie O’NEILL \| Email: Tidak diisi/);assert.match(text,/Rasa \[Tidak pedas, Tanpa santan\]/);assert.match(text,/Aktivitas \[Night ride\]; Spot & foto \[Alam & pemandangan\]; Gaya trip \[Slow trip\]/);assert.doesNotMatch(text,/Diet \[|Tidak ada|undefined|Spot invalid/);assert.match(text,/Catatan: —/);
  s.preferences["2B"].method="text";s.preferences["2B"].text="Tidak ada pantangan & suka es + jeruk.";const typed=whatsappText(s);assert.match(typed,/B\. Konsumsi: Tidak ada pantangan & suka es \+ jeruk\./);assert.doesNotMatch(typed,/Alergi \[|Rasa \[/);
  s.notes["2C"]="Jalan & foto + cerita\nboleh pelan.";const url=new URL(whatsappUrl(s));assert.equal(url.origin,"https://wa.me");assert.equal(url.pathname,"/6287791891018");assert.equal(url.searchParams.get("text"),whatsappText(s));
});
test("edit yang mereset dependensi membuat Share invalid dan item ditandai",()=>{
  const s=changeLodging(complete(),"Homestay");s.lodgingRange="C";assert.ok(isValid(s,"1A"));assert.equal(isValid(s,"2A"),false);assert.equal(answerText(s,"2A"),"Perlu diisi ulang");assert.equal(allValid(s),false);assert.equal(whatsappText(s),"");
});
test("refresh memulihkan semua draft, catatan, step, edit dan status Share",()=>{
  const s=complete();s.step="2B";s.editing="2B";s.shared=true;s.preferences["2B"].text="draft tidak aktif";s.notes["2B"]="ingat";
  const next=restoreState(JSON.stringify(s));assert.equal(next.step,"2B");assert.equal(next.editing,"2B");assert.equal(next.shared,true);assert.equal(next.preferences["2B"].text,"draft tidak aktif");assert.equal(next.notes["2B"],"ingat");assert.equal(next.introSeen,true);assert.deepEqual(next.preferences["2B"].groups.C,["Tidak pedas","Tanpa santan"]);
});
test("guard identitas dan sanitasi sesi korup",()=>{
  const s=complete();s.identity.name="a";assert.equal(restoreState(JSON.stringify(s)).step,"identity");
  assert.throws(()=>restoreState("{oops"));assert.throws(()=>restoreState('{"version":7}'));
  const corrupt={...complete(),lodging:"unknown",dailyRange:"D",notes:{"2A":"a".repeat(300)}};const next=restoreState(JSON.stringify(corrupt));assert.equal(next.lodging,"");assert.equal(next.lodgingRange,null);assert.equal(next.dailyRange,null);assert.equal(next.notes["2A"].length,250);assert.deepEqual(next.preferences["2A"].selected,[]);
});
test("mulai ulang mengembalikan semua data formulir ke kosong",()=>{
  const s=initialState();assert.equal(s.step,"identity");assert.deepEqual(s.identity,{name:"",email:""});assert.equal(s.editing,null);assert.equal(s.filledAt,null);assert.equal(s.shared,false);for(const id of questionIds)assert.equal(s.notes[id],"");assert.ok(letters.every(l=>s.preferences["2B"].groups[l].length===0));
});
